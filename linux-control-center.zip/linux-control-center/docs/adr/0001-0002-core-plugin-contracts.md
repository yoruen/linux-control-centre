# ADR-0001: Plugin API has no per-module Tauri commands

**Status:** Accepted

## Context
Each module in the spec (Software Center, Service Manager, Storage Manager,
...) needs to move nontrivial data from a plugin to the frontend — not just
the small dashboard widget payloads.

## Decision
The frontend talks to *all* plugins through the same four generic IPC
verbs (`list_plugins`, `universal_search`, `get_widget_data`,
`list_plugin_commands` + `run_plugin_command`), never a command generated
per plugin or per module. `get_widget_data(plugin_id, key)` is treated as a
general "ask this plugin for a named, read-only JSON payload" query, not
strictly limited to things that render as a dashboard grid tile — a
module page (e.g. Service Manager's full unit list) is just another
`widget_id` under the same call.

## Consequences
- Adding a new plugin never requires touching `src-tauri/src/state.rs` or
  `main.rs`'s `invoke_handler!` list.
- Plugins are responsible for giving each of their query keys a stable,
  documented name (analogous to a route or endpoint name).
- If a query genuinely needs typed request parameters beyond a single
  string key, that's the signal to add a fifth generic verb (e.g.
  `query_plugin(plugin_id, key, params: Value)`) rather than a bespoke
  command — this hasn't been needed yet.

# ADR-0002: Commands are declared data, not code

**Status:** Accepted

## Context
The security requirements call for structured, non-shell command
execution, user confirmation on destructive actions, and an AI assistant
that can "explain a command before it runs" without being able to execute
anything itself.

## Decision
A plugin never calls `Command::new(...)` itself. It *declares*
`CommandDescriptor`s (program, argv template, whether it needs Polkit,
a human-readable description, and a destructive flag) at registration
time. Actually running one goes through `HostServices::run_command`,
which the core scopes to only the commands that specific plugin declared.

This means the full list of "everything this application is capable of
doing to your system" is enumerable, at any time, without running any of
it — `list_plugin_commands` returns exactly that list. The AI assistant
explains from this same data; it has no separate/parallel execution path.

## Consequences
- A plugin cannot execute anything it didn't declare up front, even if it
  tries to build a shell string — there is no API for that.
- Confirmation-dialog copy, AI explanations, and the audit log
  (`action_history` table) all read from the same `human_description` and
  `destructive` fields, so they can never drift from what the command
  actually does.
