//! `lcc-plugin-api` is the contract between the Linux Control Center core
//! and every plugin (apt, pacman, systemd, docker, storage, ...).
//!
//! Design rules enforced by this crate's shape (see architecture docs for
//! rationale):
//! 1. The core depends on this crate; plugins depend on this crate; plugins
//!    never depend on `lcc-core`, and never depend on each other.
//! 2. There is no raw-shell-string execution primitive anywhere in this
//!    API. `CommandDescriptor` + `HostServices::run_command` is the only
//!    path to executing anything, and it is argv-based and permission
//!    checked.
//! 3. Every optional capability (widgets, search, actions, routes, event
//!    subscriptions) is a default-empty trait method, so a minimal plugin
//!    can implement just `metadata`, `initialize`, and `shutdown`.

mod error;
mod plugin;
mod types;

pub use error::PluginError;
pub use plugin::{CommandOutput, HostServices, LogLevel, Plugin, PluginContext, PluginResult};
pub use types::*;
