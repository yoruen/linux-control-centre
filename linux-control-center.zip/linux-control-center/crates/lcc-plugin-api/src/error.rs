use thiserror::Error;

#[derive(Debug, Error)]
pub enum PluginError {
    #[error("permission denied: plugin did not declare required permission {0:?}")]
    PermissionDenied(String),

    #[error("command '{0}' is not declared by this plugin")]
    UnknownCommand(String),

    #[error("privilege escalation was declined by the user")]
    PrivilegeDeclined,

    #[error("underlying tool not found: {0}")]
    ToolNotFound(String),

    #[error("io error: {0}")]
    Io(#[from] std::io::Error),

    #[error("serialization error: {0}")]
    Serde(#[from] serde_json::Error),

    #[error("plugin error: {0}")]
    Other(String),
}
