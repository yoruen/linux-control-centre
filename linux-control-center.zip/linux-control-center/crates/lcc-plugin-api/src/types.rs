//! Shared data types that make up the plugin <-> core contract.
//!
//! Nothing in this crate knows about a specific Linux tool, package manager,
//! or distribution. It only defines the *shape* of what a plugin can expose.
//! `lcc-core` depends on this crate; concrete plugins (apt, pacman, systemd,
//! docker, ...) also depend on it, but never on each other and never on
//! `lcc-core` directly. This one-directional dependency graph is what keeps
//! the core distro-agnostic and keeps plugins decoupled from one another.

use serde::{Deserialize, Serialize};
use std::fmt;

/// Stable, globally-unique identifier for a plugin, e.g. `"apt"`, `"systemd"`,
/// `"docker"`. Reused as a namespace prefix for commands, routes, and events
/// (`apt.package.install`, `systemd.service.restart`, ...).
#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct PluginId(pub String);

impl fmt::Display for PluginId {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.0)
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PluginMetadata {
    pub id: PluginId,
    pub name: String,
    pub version: String,
    pub description: String,
    pub author: String,
    /// Distro IDs (matching `/etc/os-release` `ID`/`ID_LIKE`) this plugin
    /// supports, or `None` if it works on any distro (e.g. a `systemd`
    /// plugin, or a hardware sensor plugin).
    pub supported_distros: Option<Vec<String>>,
    /// Native Linux binaries/services this plugin wraps. Used by the core
    /// at discovery time to skip plugins whose backing tool isn't installed
    /// (e.g. skip the `pacman` plugin on a system with no `pacman` binary).
    pub requires_binaries: Vec<String>,
}

/// A permission a plugin declares it needs. The core presents these to the
/// user on first activation of a plugin (similar to a mobile app permission
/// prompt) and enforces them at the boundary — a plugin cannot silently
/// escalate beyond what it declared.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum Permission {
    /// Read-only access to a filesystem path (glob allowed).
    ReadPath(String),
    /// Write access to a filesystem path (glob allowed).
    WritePath(String),
    /// Ability to request execution of specific, pre-declared structured
    /// commands that require root/Polkit escalation.
    PrivilegedExecution,
    /// Ability to execute specific, pre-declared structured commands as the
    /// current unprivileged user.
    UnprivilegedExecution,
    /// Network egress (e.g. mirror speed testing, security advisory lookup).
    Network,
    /// Subscribe to / query systemd (via D-Bus), not raw shell.
    SystemdDbus,
    /// Subscribe to udev/hardware events.
    HardwareEvents,
}

/// A *structured* command a plugin may ask the core to execute. This is the
/// only execution primitive available to plugins — there is no API that
/// accepts a raw shell string. `program` must be an absolute path or a name
/// resolved against a core-controlled allowlist; `args` are passed as an
/// argv array (never shell-interpolated).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CommandDescriptor {
    /// Unique within the plugin, e.g. `"install"`, `"remove"`, `"rollback"`.
    pub id: String,
    pub program: String,
    pub args_template: Vec<String>,
    pub requires_privilege: bool,
    /// Shown to the user in confirmation dialogs and passed to the AI
    /// assistant so it can "explain this command before it runs".
    pub human_description: String,
    /// Whether this command is destructive (removes data, uninstalls,
    /// wipes a disk, etc.) and therefore requires an explicit confirmation
    /// dialog even for unprivileged execution.
    pub destructive: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SearchResultItem {
    pub plugin_id: PluginId,
    pub category: SearchCategory,
    pub title: String,
    pub subtitle: Option<String>,
    pub icon: Option<String>,
    /// Opaque id the plugin understands, round-tripped back to it when the
    /// user activates the result (e.g. "open this package's detail pane").
    pub action_ref: String,
    /// 0.0 - 1.0, used to interleave results from multiple plugins.
    pub relevance: f32,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum SearchCategory {
    Package,
    Service,
    Process,
    LogEntry,
    Setting,
    Repository,
    User,
    Plugin,
    Command,
    Documentation,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WidgetDescriptor {
    pub id: String,
    pub title: String,
    /// Logical size hint for the dashboard grid, e.g. "1x1", "2x1", "2x2".
    pub default_size: String,
    /// Frontend route/component key the React shell resolves to a renderer.
    pub component_key: String,
    pub refresh_interval_ms: Option<u64>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ActionDescriptor {
    pub id: String,
    pub title: String,
    pub icon: Option<String>,
    /// Where this action may be surfaced: context menu, command palette, etc.
    pub contexts: Vec<ActionContext>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum ActionContext {
    CommandPalette,
    ContextMenu,
    Toolbar,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RouteDescriptor {
    /// e.g. "/software/apt"
    pub path: String,
    pub label: String,
    pub icon: Option<String>,
    pub component_key: String,
    pub nav_group: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SettingsSchema {
    /// JSON Schema describing this plugin's user-configurable settings.
    /// The core renders a generic settings form from this; plugins never
    /// ship their own settings UI code.
    pub json_schema: serde_json::Value,
}

/// Core -> plugin and plugin -> core events flow through a single bus owned
/// by the core. Plugins subscribe to topics; they never hold a reference to
/// another plugin.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Event {
    pub topic: String,
    pub source: PluginId,
    pub payload: serde_json::Value,
}
