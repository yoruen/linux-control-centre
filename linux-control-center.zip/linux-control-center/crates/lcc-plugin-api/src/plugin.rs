use crate::error::PluginError;
use crate::types::*;
use async_trait::async_trait;
use serde::{Deserialize, Serialize};
use serde_json::Value;
use tokio::sync::mpsc;

pub type PluginResult<T> = Result<T, PluginError>;

/// Handed to a plugin at `initialize()`. This is the *only* way a plugin
/// talks to the outside world — there is no ambient access to the
/// filesystem, network, or other plugins. Every method here is enforced by
/// the core against the `Permission`s the plugin declared in its manifest.
pub struct PluginContext {
    pub plugin_id: PluginId,
    /// Sender the plugin can use to publish events (e.g. "package installed").
    pub event_tx: mpsc::UnboundedSender<Event>,
    /// Handle back into the core for permission-checked operations.
    pub host: Box<dyn HostServices>,
}

/// Operations the core exposes to plugins. A trait object (rather than
/// concrete `lcc-core` types) so `lcc-plugin-api` never depends on
/// `lcc-core` — keeping the dependency arrow pointing one way.
#[async_trait]
pub trait HostServices: Send + Sync {
    /// Execute a previously-declared `CommandDescriptor` by id, with
    /// concrete argument substitutions. If `requires_privilege` is set on
    /// the descriptor, the core prompts Polkit; the plugin never sees a
    /// credential and cannot bypass the prompt.
    async fn run_command(
        &self,
        command_id: &str,
        substitutions: Vec<String>,
    ) -> PluginResult<CommandOutput>;

    /// Persist small plugin-scoped key/value config (backed by SQLite,
    /// namespaced by plugin id automatically).
    async fn get_config(&self, key: &str) -> PluginResult<Option<Value>>;
    async fn set_config(&self, key: &str, value: Value) -> PluginResult<()>;

    /// Structured logging, tagged with the plugin id automatically.
    fn log(&self, level: LogLevel, message: &str);
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CommandOutput {
    pub exit_code: i32,
    pub stdout: String,
    pub stderr: String,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LogLevel {
    Debug,
    Info,
    Warning,
    Error,
}

/// The single interface every plugin implements. All methods except
/// `metadata`, `initialize`, and `shutdown` have empty default
/// implementations, so a plugin only needs to implement the capabilities it
/// actually offers (a hardware-sensor plugin need not implement
/// `commands()`, for instance).
#[async_trait]
pub trait Plugin: Send + Sync {
    fn metadata(&self) -> PluginMetadata;

    fn permissions(&self) -> Vec<Permission> {
        Vec::new()
    }

    /// Called once, after permission grant, before any other method.
    async fn initialize(&mut self, ctx: PluginContext) -> PluginResult<()>;

    /// Called on app shutdown or plugin disable. Must release all
    /// resources (background tasks, file watchers, D-Bus subscriptions).
    async fn shutdown(&mut self) -> PluginResult<()>;

    fn commands(&self) -> Vec<CommandDescriptor> {
        Vec::new()
    }

    fn widgets(&self) -> Vec<WidgetDescriptor> {
        Vec::new()
    }

    /// Returns the current data payload for one of this plugin's
    /// `WidgetDescriptor`s, keyed by `widget_id`. Polled by the core on
    /// each widget's `refresh_interval_ms` and pushed to the frontend as a
    /// Tauri event. Kept generic (`serde_json::Value`) so the core never
    /// needs a compiled-in type per widget.
    async fn widget_data(&self, _widget_id: &str) -> PluginResult<Value> {
        Ok(Value::Null)
    }

    fn actions(&self) -> Vec<ActionDescriptor> {
        Vec::new()
    }

    fn routes(&self) -> Vec<RouteDescriptor> {
        Vec::new()
    }

    fn settings_schema(&self) -> Option<SettingsSchema> {
        None
    }

    /// Free-text search across whatever this plugin indexes (packages,
    /// services, log lines, ...). Must return quickly; plugins that need
    /// to search a large corpus should maintain their own background index
    /// rather than scanning on every keystroke.
    async fn search(&self, _query: &str) -> PluginResult<Vec<SearchResultItem>> {
        Ok(Vec::new())
    }

    /// Topics this plugin wants delivered to it, e.g. `["systemd.service.*"]`.
    fn event_subscriptions(&self) -> Vec<String> {
        Vec::new()
    }

    /// Called by the core whenever an event matching a subscription arrives.
    async fn on_event(&mut self, _event: Event) -> PluginResult<()> {
        Ok(())
    }
}
