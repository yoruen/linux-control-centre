//! Reference plugin: exposes the CPU / RAM / disk usage dashboard widgets
//! described in the "Dashboard" module of the spec. Deliberately the
//! simplest possible plugin (no privileged commands, no distro
//! restriction) so it doubles as the "hello world" example in the plugin
//! development guide.

use async_trait::async_trait;
use lcc_plugin_api::{
    Plugin, PluginContext, PluginId, PluginMetadata, PluginResult, WidgetDescriptor,
};
use serde_json::{json, Value};
use sysinfo::System;
use tokio::sync::Mutex;

pub struct SysInfoPlugin {
    system: Mutex<System>,
}

impl Default for SysInfoPlugin {
    fn default() -> Self {
        Self { system: Mutex::new(System::new_all()) }
    }
}

#[async_trait]
impl Plugin for SysInfoPlugin {
    fn metadata(&self) -> PluginMetadata {
        PluginMetadata {
            id: PluginId("sysinfo".into()),
            name: "System Info".into(),
            version: "0.1.0".into(),
            description: "CPU, memory, and disk usage widgets for the dashboard.".into(),
            author: "Linux Control Center Contributors".into(),
            // Works everywhere: no distro restriction.
            supported_distros: None,
            // Reads /proc and /sys directly; no external binary required.
            requires_binaries: Vec::new(),
        }
    }

    async fn initialize(&mut self, _ctx: PluginContext) -> PluginResult<()> {
        self.system.lock().await.refresh_all();
        Ok(())
    }

    async fn shutdown(&mut self) -> PluginResult<()> {
        Ok(())
    }

    fn widgets(&self) -> Vec<WidgetDescriptor> {
        vec![
            WidgetDescriptor {
                id: "cpu".into(),
                title: "CPU".into(),
                default_size: "1x1".into(),
                component_key: "widgets/CpuWidget".into(),
                refresh_interval_ms: Some(1500),
            },
            WidgetDescriptor {
                id: "memory".into(),
                title: "Memory".into(),
                default_size: "1x1".into(),
                component_key: "widgets/MemoryWidget".into(),
                refresh_interval_ms: Some(1500),
            },
            WidgetDescriptor {
                id: "disk".into(),
                title: "Storage".into(),
                default_size: "2x1".into(),
                component_key: "widgets/DiskWidget".into(),
                refresh_interval_ms: Some(5000),
            },
        ]
    }

    async fn widget_data(&self, widget_id: &str) -> PluginResult<Value> {
        let mut system = self.system.lock().await;
        match widget_id {
            "cpu" => {
                system.refresh_cpu_usage();
                let per_core: Vec<f32> = system.cpus().iter().map(|c| c.cpu_usage()).collect();
                let overall = if per_core.is_empty() {
                    0.0
                } else {
                    per_core.iter().sum::<f32>() / per_core.len() as f32
                };
                Ok(json!({ "overall_percent": overall, "per_core_percent": per_core }))
            }
            "memory" => {
                system.refresh_memory();
                Ok(json!({
                    "total_bytes": system.total_memory(),
                    "used_bytes": system.used_memory(),
                    "swap_total_bytes": system.total_swap(),
                    "swap_used_bytes": system.used_swap(),
                }))
            }
            "disk" => {
                // Disk enumeration lives behind a dedicated `storage`
                // plugin in the full build (Storage Manager module); this
                // reference plugin only proves the widget contract.
                Ok(json!({ "note": "see lcc-plugin-storage for full disk breakdown" }))
            }
            other => Ok(json!({ "error": format!("unknown widget id '{other}'") })),
        }
    }
}
