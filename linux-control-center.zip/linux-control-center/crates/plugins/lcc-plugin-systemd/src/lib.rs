//! Service Manager plugin: wraps `systemctl` (a stable, universally
//! present CLI) rather than talking to D-Bus directly. This keeps the
//! plugin simple and auditable — every action it can take is a single,
//! fully-declared `CommandDescriptor`, visible to the user and to the AI
//! assistant's "explain this command" flow before it ever runs.
//!
//! State-changing actions (start/stop/restart/enable/disable/mask/unmask)
//! are all `requires_privilege: true`, so the core routes them through
//! Polkit (`pkexec systemctl ...`) rather than running this whole plugin,
//! or the app, as root.

use async_trait::async_trait;
use lcc_plugin_api::{
    CommandDescriptor, HostServices, Permission, Plugin, PluginContext, PluginId, PluginMetadata,
    PluginResult, RouteDescriptor, SearchCategory, SearchResultItem, WidgetDescriptor,
};
use serde_json::{json, Value};

pub struct SystemdPlugin {
    host: Option<Box<dyn HostServices>>,
}

impl Default for SystemdPlugin {
    fn default() -> Self {
        Self { host: None }
    }
}

impl SystemdPlugin {
    fn host(&self) -> PluginResult<&dyn HostServices> {
        self.host
            .as_deref()
            .ok_or_else(|| lcc_plugin_api::PluginError::Other("plugin not initialized".into()))
    }
}

#[async_trait]
impl Plugin for SystemdPlugin {
    fn metadata(&self) -> PluginMetadata {
        PluginMetadata {
            id: PluginId("systemd".into()),
            name: "Service Manager".into(),
            version: "0.1.0".into(),
            description: "Start, stop, enable, and inspect systemd units.".into(),
            author: "Linux Control Center Contributors".into(),
            // systemd itself isn't distro-specific; presence is enforced
            // via `requires_binaries` instead, so this plugin simply never
            // activates on systemd-free distros (Alpine, Void, Gentoo
            // OpenRC setups) without needing a distro allowlist.
            supported_distros: None,
            requires_binaries: vec!["systemctl".into()],
        }
    }

    fn permissions(&self) -> Vec<Permission> {
        vec![Permission::UnprivilegedExecution, Permission::PrivilegedExecution]
    }

    async fn initialize(&mut self, ctx: PluginContext) -> PluginResult<()> {
        self.host = Some(ctx.host);
        Ok(())
    }

    async fn shutdown(&mut self) -> PluginResult<()> {
        self.host = None;
        Ok(())
    }

    fn routes(&self) -> Vec<RouteDescriptor> {
        vec![RouteDescriptor {
            path: "/services".into(),
            label: "Services".into(),
            icon: Some("cog".into()),
            component_key: "modules/ServiceManager".into(),
            nav_group: "System".into(),
        }]
    }

    fn widgets(&self) -> Vec<WidgetDescriptor> {
        vec![WidgetDescriptor {
            id: "summary".into(),
            title: "Services".into(),
            default_size: "1x1".into(),
            component_key: "widgets/ServicesSummaryWidget".into(),
            refresh_interval_ms: Some(10_000),
        }]
    }

    fn commands(&self) -> Vec<CommandDescriptor> {
        // `%UNIT%` positions are illustrative only — actual substitution is
        // purely positional (see `HostServicesImpl::run_command`): the
        // caller-provided unit name is appended as the next argv entry, it
        // is never interpolated into a string.
        let unprivileged = |id: &str, args: Vec<&str>, desc: &str| CommandDescriptor {
            id: id.into(),
            program: "systemctl".into(),
            args_template: args.into_iter().map(String::from).collect(),
            requires_privilege: false,
            human_description: desc.into(),
            destructive: false,
        };
        let privileged = |id: &str, args: Vec<&str>, desc: &str, destructive: bool| CommandDescriptor {
            id: id.into(),
            program: "systemctl".into(),
            args_template: args.into_iter().map(String::from).collect(),
            requires_privilege: true,
            human_description: desc.into(),
            destructive,
        };

        vec![
            unprivileged(
                "list-units",
                vec!["list-units", "--all", "--no-legend", "--plain", "--no-pager"],
                "List all systemd units and their current state.",
            ),
            unprivileged(
                "status",
                vec!["status", "--no-pager"],
                "Show detailed status and recent log lines for a unit.",
            ),
            privileged(
                "start",
                vec!["start"],
                "Start this unit immediately.",
                false,
            ),
            privileged("stop", vec!["stop"], "Stop this unit immediately.", false),
            privileged(
                "restart",
                vec!["restart"],
                "Stop and immediately start this unit again.",
                false,
            ),
            privileged(
                "reload",
                vec!["reload"],
                "Ask this unit to reload its configuration without restarting.",
                false,
            ),
            privileged(
                "enable",
                vec!["enable"],
                "Make this unit start automatically at boot.",
                false,
            ),
            privileged(
                "disable",
                vec!["disable"],
                "Stop this unit from starting automatically at boot.",
                false,
            ),
            privileged(
                "mask",
                vec!["mask"],
                "Prevent this unit from being started at all, even manually, until unmasked.",
                true,
            ),
            privileged(
                "unmask",
                vec!["unmask"],
                "Reverse a previous mask, allowing this unit to start again.",
                false,
            ),
        ]
    }

    async fn widget_data(&self, widget_id: &str) -> PluginResult<Value> {
        match widget_id {
            "summary" => {
                let units = self.list_units().await?;
                let running = units.iter().filter(|u| u.active == "active").count();
                let failed = units.iter().filter(|u| u.active == "failed").count();
                Ok(json!({ "total": units.len(), "running": running, "failed": failed }))
            }
            // Not a dashboard widget — the Service Manager module reuses
            // the same generic `get_widget_data` IPC verb as a read-only
            // query mechanism so the frontend doesn't need a bespoke Tauri
            // command per module. See ADR-0002 in the architecture docs.
            "unit-list" => {
                let units = self.list_units().await?;
                Ok(json!(units
                    .iter()
                    .map(|u| json!({
                        "name": u.name,
                        "active": u.active,
                        "description": u.description,
                    }))
                    .collect::<Vec<_>>()))
            }
            other => Ok(json!({ "error": format!("unknown widget id '{other}'") })),
        }
    }

    async fn search(&self, query: &str) -> PluginResult<Vec<SearchResultItem>> {
        let query_lc = query.to_lowercase();
        if query_lc.trim().is_empty() {
            return Ok(Vec::new());
        }
        let units = self.list_units().await?;
        let results = units
            .into_iter()
            .filter(|u| u.name.to_lowercase().contains(&query_lc) || u.description.to_lowercase().contains(&query_lc))
            .take(25)
            .map(|u| {
                let relevance = if u.name.to_lowercase().starts_with(&query_lc) { 0.95 } else { 0.6 };
                SearchResultItem {
                    plugin_id: PluginId("systemd".into()),
                    category: SearchCategory::Service,
                    title: u.name.clone(),
                    subtitle: Some(format!("{} · {}", u.active, u.description)),
                    icon: None,
                    action_ref: u.name,
                    relevance,
                }
            })
            .collect();
        Ok(results)
    }
}

struct UnitRow {
    name: String,
    active: String,
    description: String,
}

impl SystemdPlugin {
    async fn list_units(&self) -> PluginResult<Vec<UnitRow>> {
        let output = self.host()?.run_command("list-units", Vec::new()).await?;
        Ok(output
            .stdout
            .lines()
            .filter_map(|line| {
                // UNIT LOAD ACTIVE SUB DESCRIPTION...
                let mut parts = line.split_whitespace();
                let name = parts.next()?.to_string();
                let _load = parts.next()?;
                let active = parts.next()?.to_string();
                let _sub = parts.next()?;
                let description = parts.collect::<Vec<_>>().join(" ");
                Some(UnitRow { name, active, description })
            })
            .collect())
    }
}
