//! `lcc-core` is the distro-agnostic engine: plugin discovery/lifecycle,
//! the event bus, the SQLite store, and the single structured-command
//! executor. It has zero knowledge of `apt`, `pacman`, `systemd`, `docker`,
//! or any other concrete tool — that knowledge lives entirely in plugins
//! implementing `lcc_plugin_api::Plugin`.

pub mod db;
pub mod distro;
pub mod error;
pub mod event_bus;
pub mod exec;
pub mod host;
pub mod registry;

pub use distro::DistroInfo;
pub use error::CoreError;
pub use registry::PluginRegistry;
