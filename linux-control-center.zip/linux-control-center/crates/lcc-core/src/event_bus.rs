//! Plugins publish events by sending on the `mpsc::UnboundedSender<Event>`
//! given to them in `PluginContext`. The core (this module) is the only
//! thing that reads those receivers, matches `event.topic` against every
//! *other* plugin's declared subscriptions, and re-dispatches. A plugin
//! therefore can never hold a handle to another plugin — every interaction
//! is topic-based and mediated here, which is what lets plugins be added,
//! removed, or crash independently without the others knowing.

use lcc_plugin_api::{Event, PluginId};
use std::collections::HashMap;
use tokio::sync::mpsc::UnboundedReceiver;

pub struct EventBus {
    subscriptions: HashMap<PluginId, Vec<String>>,
}

impl EventBus {
    pub fn new() -> Self {
        Self { subscriptions: HashMap::new() }
    }

    /// Registers what topics `plugin_id` cares about, and spawns a task
    /// that drains its outgoing event receiver and fans it out. In this
    /// scaffold the fan-out target (calling `on_event` on subscribers) is
    /// left as a `tracing` log line; wiring it to `PluginRegistry` requires
    /// `PluginRegistry` to hand the bus an `Arc` back to itself, which is
    /// the next piece to implement alongside the first real plugin pair
    /// (e.g. `systemd` publishing, `dashboard` subscribing).
    pub fn subscribe(
        &mut self,
        plugin_id: PluginId,
        topics: Vec<String>,
        mut rx: UnboundedReceiver<Event>,
    ) {
        self.subscriptions.insert(plugin_id.clone(), topics);
        tokio::spawn(async move {
            while let Some(event) = rx.recv().await {
                tracing::debug!(
                    from = %event.source,
                    topic = %event.topic,
                    "event published (fan-out not yet wired to registry)"
                );
            }
        });
    }

    pub fn topics_for(&self, plugin_id: &PluginId) -> &[String] {
        self.subscriptions
            .get(plugin_id)
            .map(|v| v.as_slice())
            .unwrap_or(&[])
    }
}
