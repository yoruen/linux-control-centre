use crate::db::Db;
use crate::distro::DistroInfo;
use crate::error::CoreError;
use crate::event_bus::EventBus;
use crate::host::{CommandTable, HostServicesImpl};
use lcc_plugin_api::{Event, Plugin, PluginContext, PluginId, PluginMetadata};
use std::collections::HashMap;
use std::sync::Arc;
use tokio::sync::{Mutex, RwLock};

/// Owns every loaded plugin and is the single point through which the rest
/// of the application (Tauri commands) talks to plugins. Plugins never get
/// a reference to this registry or to each other — only to `HostServices`.
pub struct PluginRegistry {
    plugins: HashMap<PluginId, Arc<Mutex<Box<dyn Plugin>>>>,
    metadata: HashMap<PluginId, PluginMetadata>,
    distro: DistroInfo,
    db: Db,
    event_bus: EventBus,
    commands: CommandTable,
}

impl PluginRegistry {
    pub fn new(distro: DistroInfo, db: Db) -> Self {
        Self {
            plugins: HashMap::new(),
            metadata: HashMap::new(),
            distro,
            db,
            event_bus: EventBus::new(),
            commands: Arc::new(RwLock::new(HashMap::new())),
        }
    }

    /// Checks distro compatibility and required-binary availability *before*
    /// calling `initialize()`. A plugin whose backing tool (e.g. `pacman`)
    /// isn't present simply never activates — no error dialog, since this
    /// is the expected case on every distro that isn't the plugin's target.
    pub fn is_eligible(&self, metadata: &PluginMetadata) -> bool {
        let distro_ok = match &metadata.supported_distros {
            None => true,
            Some(list) => list.iter().any(|d| self.distro.matches(d)),
        };
        let binaries_ok = metadata
            .requires_binaries
            .iter()
            .all(|bin| which_exists(bin));

        distro_ok && binaries_ok
    }

    pub async fn register(&mut self, mut plugin: Box<dyn Plugin>) -> Result<(), CoreError> {
        let metadata = plugin.metadata();
        let id = metadata.id.clone();

        if self.plugins.contains_key(&id) {
            return Err(CoreError::DuplicatePlugin(id.to_string()));
        }
        if !self.is_eligible(&metadata) {
            // Not an error: this is the expected, common case (e.g. the
            // `systemd` plugin on a distro with no `systemctl`). The
            // caller loops over every built-in plugin and register() must
            // not abort that loop just because one of them doesn't apply
            // here.
            tracing::info!(plugin = %id, "skipping plugin: not eligible on this system");
            return Ok(());
        }

        let declared_commands = plugin
            .commands()
            .into_iter()
            .map(|c| (c.id.clone(), c))
            .collect::<HashMap<_, _>>();
        self.commands.write().await.insert(id.clone(), declared_commands);

        let (event_tx, event_rx) = tokio::sync::mpsc::unbounded_channel::<Event>();
        let host = HostServicesImpl::with_command_table(id.clone(), self.db.clone(), self.commands.clone());
        let ctx = PluginContext {
            plugin_id: id.clone(),
            event_tx,
            host: Box::new(host),
        };

        plugin.initialize(ctx).await?;

        self.event_bus.subscribe(id.clone(), plugin.event_subscriptions(), event_rx);
        self.metadata.insert(id.clone(), metadata);
        self.plugins.insert(id, Arc::new(Mutex::new(plugin)));
        Ok(())
    }

    pub async fn shutdown_all(&mut self) {
        for (_id, plugin) in self.plugins.drain() {
            let mut p = plugin.lock().await;
            let _ = p.shutdown().await;
        }
    }

    pub fn list_metadata(&self) -> Vec<PluginMetadata> {
        self.metadata.values().cloned().collect()
    }

    pub fn get(&self, id: &PluginId) -> Option<Arc<Mutex<Box<dyn Plugin>>>> {
        self.plugins.get(id).cloned()
    }

    /// Every `CommandDescriptor` a plugin declared, for confirmation
    /// dialogs and the AI assistant's "explain this command before it
    /// runs" flow. Returned to the frontend verbatim — the frontend never
    /// invents its own copy of what a command does.
    pub async fn list_commands(&self, plugin_id: &PluginId) -> Vec<lcc_plugin_api::CommandDescriptor> {
        self.commands
            .read()
            .await
            .get(plugin_id)
            .map(|m| m.values().cloned().collect())
            .unwrap_or_default()
    }

    /// Runs a previously-declared command by id. Goes through the same
    /// permission-checked `HostServicesImpl` a plugin itself would use —
    /// there is exactly one code path from "a command runs" back to
    /// `exec::execute`, whether the request originated inside a plugin or
    /// from a direct user action in the UI.
    pub async fn run_command(
        &self,
        plugin_id: &PluginId,
        command_id: &str,
        substitutions: Vec<String>,
    ) -> Result<lcc_plugin_api::CommandOutput, CoreError> {
        use lcc_plugin_api::HostServices;
        let host = HostServicesImpl::with_command_table(
            plugin_id.clone(),
            self.db.clone(),
            self.commands.clone(),
        );
        host.run_command(command_id, substitutions)
            .await
            .map_err(CoreError::from)
    }

    /// Aggregates search results from every loaded plugin in parallel, per
    /// the "Universal Search" requirement. A slow or hung plugin is capped
    /// with a timeout so it can never block the rest of the results.
    pub async fn search_all(&self, query: &str) -> Vec<lcc_plugin_api::SearchResultItem> {
        let mut handles = Vec::new();
        for plugin in self.plugins.values().cloned() {
            let query = query.to_string();
            handles.push(tokio::spawn(async move {
                let guard = plugin.lock().await;
                tokio::time::timeout(
                    std::time::Duration::from_millis(800),
                    guard.search(&query),
                )
                .await
                .unwrap_or(Ok(Vec::new()))
                .unwrap_or_default()
            }));
        }

        let mut results = Vec::new();
        for handle in handles {
            if let Ok(mut items) = handle.await {
                results.append(&mut items);
            }
        }
        results.sort_by(|a, b| b.relevance.partial_cmp(&a.relevance).unwrap());
        results
    }
}

fn which_exists(bin: &str) -> bool {
    std::env::var_os("PATH")
        .map(|paths| {
            std::env::split_paths(&paths).any(|dir| dir.join(bin).is_file())
        })
        .unwrap_or(false)
}
