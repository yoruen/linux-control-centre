//! The *only* place in the entire application that spawns a process.
//!
//! Two hard rules enforced here, matching the security section of the
//! project spec:
//! 1. Commands are always argv arrays (`program`, `Vec<args>`). There is no
//!    function anywhere that takes a single shell string and hands it to
//!    `/bin/sh -c`.
//! 2. Privileged commands never run through `sudo` with a cached password.
//!    They go through `pkexec` (Polkit), so the OS itself owns the
//!    authentication prompt and policy — the app process never sees or
//!    stores a credential.

use lcc_plugin_api::CommandOutput;
use tokio::process::Command;

#[derive(Debug, Clone)]
pub struct StructuredCommand {
    pub program: String,
    pub args: Vec<String>,
    pub requires_privilege: bool,
}

/// Executable allowlist. Even a compromised or buggy plugin can only ever
/// request execution of a `CommandDescriptor` it declared at registration
/// time (checked in `host.rs` before this function is ever reached); this
/// is a second, independent layer that rejects anything not resolvable to
/// an absolute, real path.
pub async fn execute(cmd: StructuredCommand) -> anyhow::Result<CommandOutput> {
    let resolved = resolve_program_path(&cmd.program)
        .ok_or_else(|| anyhow::anyhow!("refusing to execute unresolved program '{}'", cmd.program))?;

    let mut invocation = if cmd.requires_privilege {
        // pkexec launches the target under Polkit's authentication agent.
        // The GUI prompt, credential handling, and policy rules
        // (/usr/share/polkit-1/actions/*.policy) are entirely owned by the
        // OS, not by this application.
        let mut c = Command::new("/usr/bin/pkexec");
        c.arg(&resolved);
        c
    } else {
        Command::new(&resolved)
    };

    invocation.args(&cmd.args);
    invocation.kill_on_drop(true);

    let output = invocation.output().await?;

    Ok(CommandOutput {
        exit_code: output.status.code().unwrap_or(-1),
        stdout: String::from_utf8_lossy(&output.stdout).into_owned(),
        stderr: String::from_utf8_lossy(&output.stderr).into_owned(),
    })
}

/// Resolves a program name to an absolute path via `which`-equivalent
/// lookup, refusing anything containing shell metacharacters, relative
/// traversal, or whitespace. This is defense in depth, not the primary
/// control (the primary control is that we never build a shell string).
fn resolve_program_path(program: &str) -> Option<String> {
    if program.contains(['|', '&', ';', '$', '`', '\n', '>', '<']) {
        return None;
    }
    let path = if program.starts_with('/') {
        std::path::PathBuf::from(program)
    } else {
        which_lookup(program)?
    };
    if path.is_file() {
        path.to_str().map(str::to_string)
    } else {
        None
    }
}

fn which_lookup(program: &str) -> Option<std::path::PathBuf> {
    let path_var = std::env::var_os("PATH")?;
    for dir in std::env::split_paths(&path_var) {
        let candidate = dir.join(program);
        if candidate.is_file() {
            return Some(candidate);
        }
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rejects_shell_metacharacters() {
        assert!(resolve_program_path("apt-get; rm -rf /").is_none());
        assert!(resolve_program_path("echo `whoami`").is_none());
    }
}
