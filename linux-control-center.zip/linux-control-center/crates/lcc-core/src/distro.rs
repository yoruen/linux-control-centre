//! Distribution detection. The core never hardcodes "if Ubuntu do X" —
//! it only extracts `ID` / `ID_LIKE` from `/etc/os-release` and uses that
//! to decide *which plugins are eligible to load*. All distro-specific
//! behavior lives inside plugins.

use std::collections::HashMap;
use std::path::Path;

#[derive(Debug, Clone, Default)]
pub struct DistroInfo {
    pub id: String,
    pub id_like: Vec<String>,
    pub pretty_name: String,
    pub version_id: Option<String>,
}

impl DistroInfo {
    /// Returns true if `candidate` matches this distro's `ID` or appears in
    /// `ID_LIKE` (e.g. EndeavourOS has `ID_LIKE=arch`, so a plugin declaring
    /// support for `"arch"` will still be eligible).
    pub fn matches(&self, candidate: &str) -> bool {
        self.id.eq_ignore_ascii_case(candidate)
            || self.id_like.iter().any(|l| l.eq_ignore_ascii_case(candidate))
    }

    pub fn detect() -> anyhow::Result<Self> {
        Self::detect_from(Path::new("/etc/os-release"))
    }

    fn detect_from(path: &Path) -> anyhow::Result<Self> {
        let content = std::fs::read_to_string(path)
            .map_err(|e| anyhow::anyhow!("could not read {}: {e}", path.display()))?;
        Ok(Self::parse(&content))
    }

    fn parse(content: &str) -> Self {
        let mut map: HashMap<String, String> = HashMap::new();
        for line in content.lines() {
            let line = line.trim();
            if line.is_empty() || line.starts_with('#') {
                continue;
            }
            if let Some((key, value)) = line.split_once('=') {
                let value = value.trim().trim_matches('"').to_string();
                map.insert(key.trim().to_string(), value);
            }
        }
        DistroInfo {
            id: map.get("ID").cloned().unwrap_or_else(|| "unknown".into()),
            id_like: map
                .get("ID_LIKE")
                .map(|v| v.split_whitespace().map(str::to_string).collect())
                .unwrap_or_default(),
            pretty_name: map.get("PRETTY_NAME").cloned().unwrap_or_default(),
            version_id: map.get("VERSION_ID").cloned(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_ubuntu_style_os_release() {
        let content = r#"
PRETTY_NAME="Ubuntu 24.04 LTS"
NAME="Ubuntu"
VERSION_ID="24.04"
ID=ubuntu
ID_LIKE=debian
"#;
        let info = DistroInfo::parse(content);
        assert_eq!(info.id, "ubuntu");
        assert_eq!(info.id_like, vec!["debian".to_string()]);
        assert!(info.matches("ubuntu"));
        assert!(info.matches("debian"));
        assert!(!info.matches("arch"));
    }

    #[test]
    fn parses_endeavouros_id_like_arch() {
        let content = r#"
NAME="EndeavourOS"
ID=endeavouros
ID_LIKE=arch
"#;
        let info = DistroInfo::parse(content);
        assert!(info.matches("arch"));
    }
}
