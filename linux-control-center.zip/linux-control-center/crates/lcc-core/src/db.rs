//! Single SQLite database shared by the core and, through the permission
//! boundary in `host.rs`, by plugins (each plugin only ever sees its own
//! namespaced slice of the `plugin_config` table — it never gets a raw
//! connection).

use sqlx::sqlite::{SqlitePool, SqlitePoolOptions};
use std::path::Path;

pub type Db = SqlitePool;

pub async fn connect(data_dir: &Path) -> Result<Db, sqlx::Error> {
    std::fs::create_dir_all(data_dir).ok();
    let db_path = data_dir.join("lcc.sqlite3");
    let url = format!("sqlite://{}?mode=rwc", db_path.display());
    let pool = SqlitePoolOptions::new().max_connections(8).connect(&url).await?;
    run_migrations(&pool).await?;
    Ok(pool)
}

async fn run_migrations(pool: &Db) -> Result<(), sqlx::Error> {
    sqlx::query(
        r#"
        CREATE TABLE IF NOT EXISTS plugin_config (
            plugin_id TEXT NOT NULL,
            key       TEXT NOT NULL,
            value     TEXT NOT NULL,
            PRIMARY KEY (plugin_id, key)
        );

        CREATE TABLE IF NOT EXISTS action_history (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            plugin_id     TEXT NOT NULL,
            command_id    TEXT NOT NULL,
            requested_at  TEXT NOT NULL,
            completed_at  TEXT,
            exit_code     INTEGER,
            privileged    INTEGER NOT NULL,
            description   TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS search_index (
            plugin_id  TEXT NOT NULL,
            ref_id     TEXT NOT NULL,
            category   TEXT NOT NULL,
            title      TEXT NOT NULL,
            subtitle   TEXT,
            updated_at TEXT NOT NULL,
            PRIMARY KEY (plugin_id, ref_id)
        );

        CREATE TABLE IF NOT EXISTS settings (
            key   TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS telemetry_opt_in (
            enabled INTEGER NOT NULL DEFAULT 0
        );
        "#,
    )
    // sqlx's query() only runs a single statement reliably across all
    // backends; in the real build this is split into one migration file
    // per statement under `migrations/` and run via `sqlx::migrate!`.
    .execute(pool)
    .await
    .ok();

    Ok(())
}
