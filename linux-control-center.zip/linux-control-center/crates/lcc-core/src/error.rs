use thiserror::Error;

#[derive(Debug, Error)]
pub enum CoreError {
    #[error("plugin '{0}' is already registered")]
    DuplicatePlugin(String),

    #[error("plugin '{0}' not found")]
    PluginNotFound(String),

    #[error("plugin '{0}' is not compatible with this distribution")]
    IncompatibleDistro(String),

    #[error("required binary '{0}' not found on PATH")]
    MissingBinary(String),

    #[error("database error: {0}")]
    Database(#[from] sqlx::Error),

    #[error("plugin api error: {0}")]
    Plugin(#[from] lcc_plugin_api::PluginError),

    #[error(transparent)]
    Other(#[from] anyhow::Error),
}
