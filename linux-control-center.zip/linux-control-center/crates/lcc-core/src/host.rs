use crate::db::Db;
use crate::exec::{self, StructuredCommand};
use async_trait::async_trait;
use lcc_plugin_api::{CommandDescriptor, CommandOutput, HostServices, LogLevel, PluginError, PluginId, PluginResult};
use serde_json::Value;
use std::collections::HashMap;
use std::sync::Arc;
use tokio::sync::RwLock;

/// Global table of every command a plugin declared at registration. Checked
/// on every `run_command` call so a plugin can never execute something it
/// didn't declare up front (declared commands are visible to the user and
/// to the AI assistant's "explain before running" flow).
pub type CommandTable = Arc<RwLock<HashMap<PluginId, HashMap<String, CommandDescriptor>>>>;

pub struct HostServicesImpl {
    plugin_id: PluginId,
    db: Db,
    commands: CommandTable,
}

impl HostServicesImpl {
    pub fn new(plugin_id: PluginId, db: Db) -> Self {
        Self { plugin_id, db, commands: Arc::new(RwLock::new(HashMap::new())) }
    }

    pub fn with_command_table(plugin_id: PluginId, db: Db, commands: CommandTable) -> Self {
        Self { plugin_id, db, commands }
    }
}

#[async_trait]
impl HostServices for HostServicesImpl {
    async fn run_command(
        &self,
        command_id: &str,
        substitutions: Vec<String>,
    ) -> PluginResult<CommandOutput> {
        let table = self.commands.read().await;
        let descriptor = table
            .get(&self.plugin_id)
            .and_then(|m| m.get(command_id))
            .ok_or_else(|| PluginError::UnknownCommand(command_id.to_string()))?
            .clone();
        drop(table);

        // Template substitution is positional and argv-based — substitutions
        // are appended as additional argv entries, never interpolated into
        // a string that could be re-parsed by a shell.
        let mut args = descriptor.args_template.clone();
        args.extend(substitutions);

        let cmd = StructuredCommand {
            program: descriptor.program.clone(),
            args,
            requires_privilege: descriptor.requires_privilege,
        };

        exec::execute(cmd)
            .await
            .map_err(|e| PluginError::Other(e.to_string()))
    }

    async fn get_config(&self, key: &str) -> PluginResult<Option<Value>> {
        let row: Option<(String,)> = sqlx::query_as(
            "SELECT value FROM plugin_config WHERE plugin_id = ? AND key = ?",
        )
        .bind(self.plugin_id.0.clone())
        .bind(key)
        .fetch_optional(&self.db)
        .await
        .map_err(|e| PluginError::Other(e.to_string()))?;

        Ok(row.and_then(|(v,)| serde_json::from_str(&v).ok()))
    }

    async fn set_config(&self, key: &str, value: Value) -> PluginResult<()> {
        let serialized = serde_json::to_string(&value)?;
        sqlx::query(
            "INSERT INTO plugin_config (plugin_id, key, value) VALUES (?, ?, ?)
             ON CONFLICT(plugin_id, key) DO UPDATE SET value = excluded.value",
        )
        .bind(self.plugin_id.0.clone())
        .bind(key)
        .bind(serialized)
        .execute(&self.db)
        .await
        .map_err(|e| PluginError::Other(e.to_string()))?;
        Ok(())
    }

    fn log(&self, level: LogLevel, message: &str) {
        match level {
            LogLevel::Debug => tracing::debug!(plugin = %self.plugin_id, "{message}"),
            LogLevel::Info => tracing::info!(plugin = %self.plugin_id, "{message}"),
            LogLevel::Warning => tracing::warn!(plugin = %self.plugin_id, "{message}"),
            LogLevel::Error => tracing::error!(plugin = %self.plugin_id, "{message}"),
        }
    }
}
