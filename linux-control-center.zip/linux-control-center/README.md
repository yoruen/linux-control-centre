# Linux Control Center

An all-in-one Linux desktop management suite (Tauri + Rust + React), built
as a distro-agnostic core with a plugin for every native tool it wraps
(package managers, systemd, docker, ...).

## Status: early scaffold, milestone 1 of many

This repository currently contains:

- **`lcc-plugin-api`** — the contract every plugin implements. See its
  module doc comment and `docs/adr/0001-0002-core-plugin-contracts.md`.
- **`lcc-core`** — distro detection, plugin registry/lifecycle, event bus,
  the single structured-command executor, SQLite wiring.
- **`lcc-plugin-sysinfo`** — reference plugin: CPU/Memory dashboard widgets.
- **`lcc-plugin-systemd`** — Service Manager module: list/start/stop/
  restart/enable/disable/mask units via `systemctl`, all privileged actions
  routed through Polkit.
- **`src-tauri`** — the app shell: refuses to run as root, boots the
  registry, exposes five generic IPC verbs.
- **`frontend`** — React/TypeScript shell: sidebar nav for every module in
  the spec, a live Dashboard, and a working Services page with confirm-
  before-run dialogs.

Every other module described in the original spec (Software Center, Update
Center, Storage Manager, Hardware Center, Networking, Security Center,
Backup Center, Containers, VMs, Logs, the AI assistant, Universal Search
UI, i18n, full test suite, CI/CD) is **not built yet**. The nav links to
those routes render an honest "not built yet" placeholder rather than fake
content.

## Why this shape (short version)

- **Core knows nothing about `apt`/`pacman`/`systemd`/etc.** Only plugins
  do. The core only ever sees `Plugin` trait objects. This is what lets
  distro-specific and tool-specific code evolve independently and lets the
  core stay small and stable.
- **No raw shell strings, anywhere.** Every executable action a plugin can
  take is a declared `CommandDescriptor` (program + argv template), run
  through one function (`lcc_core::exec::execute`). Privileged commands go
  through `pkexec` (Polkit) — the app process itself never runs as root and
  never handles a credential.
- **The frontend never gets a bespoke command per plugin.** Five generic
  IPC verbs cover every module; see `docs/adr/`.

## Building this yourself

This was scaffolded in a sandbox with **no Rust toolchain and no network
access**, so none of it has been compiled or run. Before trusting it:

```bash
# Rust side
cargo build --workspace

# Frontend
cd frontend
npm install
npm run build

# Full app (from repo root, requires the Tauri CLI: cargo install tauri-cli)
cargo tauri dev
```

You'll also need, on the target machine: `pkexec` (part of Polkit, present
on virtually every desktop distro), and `systemctl` if you want the
Service Manager module to activate (it silently no-ops on non-systemd
distros).

Expect some first-build friction — dependency versions (`tauri = "2"`,
`sqlx`, `sysinfo`) were chosen from general knowledge, not verified against
a live `cargo build`, so version pins may need small adjustments.

## Suggested next milestones

In spec order, roughly by value: Software Center (the biggest, wraps
apt/pacman/dnf/zypper/flatpak/snap), Update Center (aggregates the above),
Process Manager, Storage Manager, then Security/Backup/Containers.
