export interface UnitRow {
  name: string;
  active: string;
  description: string;
}

export interface ServicesSummary {
  total: number;
  running: number;
  failed: number;
}

export interface CommandDescriptor {
  id: string;
  program: string;
  args_template: string[];
  requires_privilege: boolean;
  human_description: string;
  destructive: boolean;
}

export interface CommandOutput {
  exit_code: number;
  stdout: string;
  stderr: string;
}
