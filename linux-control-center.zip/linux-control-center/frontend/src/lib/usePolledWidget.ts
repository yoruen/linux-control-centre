import { useEffect, useState } from "react";
import { api } from "./tauri";

/**
 * Polls a widget's data at the interval its own `WidgetDescriptor` declared
 * on the Rust side. Every dashboard widget uses this same hook — no widget
 * component talks to Tauri directly, so swapping the transport later
 * (moving to a push-based Tauri event instead of polling) only touches
 * this one file.
 */
export function usePolledWidget<T>(pluginId: string, widgetId: string, intervalMs: number) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    async function tick() {
      try {
        const result = await api.getWidgetData<T>(pluginId, widgetId);
        if (!cancelled) {
          setData(result);
          setError(null);
        }
      } catch (err) {
        if (!cancelled) setError(String(err));
      }
    }

    tick();
    const id = setInterval(tick, intervalMs);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, [pluginId, widgetId, intervalMs]);

  return { data, error };
}
