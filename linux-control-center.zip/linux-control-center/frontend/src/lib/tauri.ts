import { invoke } from "@tauri-apps/api/core";
import type { PluginMetadata, SearchResultItem } from "../types";
import type { CommandDescriptor, CommandOutput } from "../types-systemd";

/**
 * The frontend only ever calls a small, fixed set of generic IPC verbs —
 * see `src-tauri/src/state.rs` and ADR-0001 in `docs/adr/`. No plugin ever
 * needs a bespoke Tauri command of its own.
 */
export const api = {
  listPlugins: () => invoke<PluginMetadata[]>("list_plugins"),

  search: (query: string) =>
    invoke<SearchResultItem[]>("universal_search", { query }),

  getWidgetData: <T>(pluginId: string, widgetId: string) =>
    invoke<T>("get_widget_data", { pluginId, widgetId }),

  listPluginCommands: (pluginId: string) =>
    invoke<CommandDescriptor[]>("list_plugin_commands", { pluginId }),

  /**
   * Runs a previously-declared command. Callers MUST show a confirmation
   * dialog first when the matching `CommandDescriptor.destructive` is true
   * or `requires_privilege` is true — this function itself performs no
   * confirmation.
   */
  runPluginCommand: (pluginId: string, commandId: string, substitutions: string[] = []) =>
    invoke<CommandOutput>("run_plugin_command", {
      pluginId,
      commandId,
      substitutions,
    }),
};
