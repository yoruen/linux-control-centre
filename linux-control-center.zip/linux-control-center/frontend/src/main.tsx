import ReactDOM from "react-dom/client";
import "./theme.css";
import { App } from "./App";

ReactDOM.createRoot(document.getElementById("root")!).render(<App />);
