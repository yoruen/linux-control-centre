// Mirrors the serde-serialized shapes from `lcc-plugin-api::types`. Kept as
// a hand-written mirror for now; once the schema stabilizes this should be
// generated from the Rust types (e.g. via `ts-rs`) so the two never drift.

export interface PluginMetadata {
  id: { 0: string } | string;
  name: string;
  version: string;
  description: string;
  author: string;
  supported_distros: string[] | null;
  requires_binaries: string[];
}

export type SearchCategory =
  | "Package"
  | "Service"
  | "Process"
  | "LogEntry"
  | "Setting"
  | "Repository"
  | "User"
  | "Plugin"
  | "Command"
  | "Documentation";

export interface SearchResultItem {
  plugin_id: string;
  category: SearchCategory;
  title: string;
  subtitle?: string;
  icon?: string;
  action_ref: string;
  relevance: number;
}

export interface CpuWidgetData {
  overall_percent: number;
  per_core_percent: number[];
}

export interface MemoryWidgetData {
  total_bytes: number;
  used_bytes: number;
  swap_total_bytes: number;
  swap_used_bytes: number;
}
