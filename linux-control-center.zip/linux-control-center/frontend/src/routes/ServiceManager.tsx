import { useEffect, useMemo, useState } from "react";
import { api } from "../lib/tauri";
import { ConfirmDialog } from "../components/ConfirmDialog";
import type { CommandDescriptor, UnitRow } from "../types-systemd";
import "./ServiceManager.css";

const PLUGIN_ID = "systemd";

export function ServiceManager() {
  const [units, setUnits] = useState<UnitRow[]>([]);
  const [commands, setCommands] = useState<CommandDescriptor[]>([]);
  const [filter, setFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [pending, setPending] = useState<{ command: CommandDescriptor; unit: string } | null>(null);
  const [lastResult, setLastResult] = useState<string | null>(null);

  async function refresh() {
    setLoading(true);
    try {
      const [unitData, commandData] = await Promise.all([
        api.getWidgetData<UnitRow[]>(PLUGIN_ID, "unit-list"),
        api.listPluginCommands(PLUGIN_ID),
      ]);
      setUnits(unitData);
      setCommands(commandData);
      setLoadError(null);
    } catch (err) {
      setLoadError(String(err));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    refresh();
  }, []);

  const filtered = useMemo(() => {
    const q = filter.toLowerCase();
    return units.filter(
      (u) => u.name.toLowerCase().includes(q) || u.description.toLowerCase().includes(q)
    );
  }, [units, filter]);

  function commandFor(id: string) {
    return commands.find((c) => c.id === id);
  }

  async function runConfirmed() {
    if (!pending) return;
    const { command, unit } = pending;
    setPending(null);
    try {
      const result = await api.runPluginCommand(PLUGIN_ID, command.id, [unit]);
      setLastResult(
        result.exit_code === 0
          ? `${command.id} ${unit} succeeded.`
          : `${command.id} ${unit} exited with code ${result.exit_code}: ${result.stderr.trim()}`
      );
      refresh();
    } catch (err) {
      setLastResult(String(err));
    }
  }

  return (
    <div>
      <h2 style={{ marginBottom: 4 }}>Services</h2>
      <p style={{ color: "var(--color-text-faint)", fontSize: 13, marginBottom: 16 }}>
        {units.length} systemd units on this machine.
      </p>

      <input
        className="service-manager__filter"
        placeholder="Filter services…"
        value={filter}
        onChange={(e) => setFilter(e.target.value)}
        aria-label="Filter services"
      />

      {loadError && <p style={{ color: "var(--color-ember)" }}>{loadError}</p>}
      {lastResult && <p className="mono service-manager__result">{lastResult}</p>}

      {loading ? (
        <p style={{ color: "var(--color-text-faint)" }}>Loading…</p>
      ) : (
        <table className="service-manager__table">
          <thead>
            <tr>
              <th>Unit</th>
              <th>State</th>
              <th>Description</th>
              <th aria-label="Actions" />
            </tr>
          </thead>
          <tbody>
            {filtered.map((unit) => (
              <tr key={unit.name}>
                <td className="mono">{unit.name}</td>
                <td>
                  <span className={`service-manager__badge service-manager__badge--${unit.active}`}>
                    {unit.active}
                  </span>
                </td>
                <td>{unit.description}</td>
                <td className="service-manager__actions">
                  {["start", "stop", "restart"].map((id) => {
                    const command = commandFor(id);
                    if (!command) return null;
                    return (
                      <button
                        key={id}
                        onClick={() => setPending({ command, unit: unit.name })}
                        className="service-manager__action-btn"
                      >
                        {id}
                      </button>
                    );
                  })}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {pending && (
        <ConfirmDialog
          command={pending.command}
          targetLabel={pending.unit}
          onConfirm={runConfirmed}
          onCancel={() => setPending(null)}
        />
      )}
    </div>
  );
}
