export function ComingSoon({ moduleName }: { moduleName: string }) {
  return (
    <div>
      <h2 style={{ marginBottom: 4 }}>{moduleName}</h2>
      <p style={{ color: "var(--color-text-faint)", fontSize: 13, maxWidth: 480 }}>
        This module hasn't been built yet. The plugin framework and dashboard
        are in place — {moduleName.toLowerCase()} is next up on the roadmap.
      </p>
    </div>
  );
}
