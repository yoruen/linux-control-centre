import { CpuWidget } from "../components/widgets/CpuWidget";
import { MemoryWidget } from "../components/widgets/MemoryWidget";
import { DiskWidget } from "../components/widgets/DiskWidget";
import { ServicesSummaryWidget } from "../components/widgets/ServicesSummaryWidget";
import "./Dashboard.css";

export function Dashboard() {
  return (
    <div>
      <h2 style={{ marginBottom: 4 }}>Dashboard</h2>
      <p style={{ color: "var(--color-text-faint)", fontSize: 13, marginBottom: 20 }}>
        Live overview of this machine.
      </p>
      <div className="dashboard-grid">
        <CpuWidget />
        <MemoryWidget />
        <ServicesSummaryWidget />
        <DiskWidget />
      </div>
    </div>
  );
}
