import type { ReactNode } from "react";
import "./WidgetCard.css";

export function WidgetCard({
  title,
  span = 1,
  pulse,
  children,
}: {
  title: string;
  span?: 1 | 2;
  pulse?: ReactNode;
  children: ReactNode;
}) {
  return (
    <section className="widget-card" style={{ gridColumn: `span ${span}` }} aria-label={title}>
      {pulse}
      <h3 className="widget-card__title">{title}</h3>
      <div className="widget-card__body">{children}</div>
    </section>
  );
}
