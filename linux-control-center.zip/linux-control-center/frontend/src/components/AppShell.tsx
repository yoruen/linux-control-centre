import { NavLink, Outlet } from "react-router-dom";
import "./AppShell.css";

const NAV_GROUPS: { label: string; items: { to: string; label: string }[] }[] = [
  {
    label: "Overview",
    items: [{ to: "/", label: "Dashboard" }],
  },
  {
    label: "Software",
    items: [
      { to: "/software", label: "Software Center" },
      { to: "/updates", label: "Update Center" },
      { to: "/repositories", label: "Repositories" },
    ],
  },
  {
    label: "System",
    items: [
      { to: "/services", label: "Services" },
      { to: "/processes", label: "Processes" },
      { to: "/startup", label: "Startup" },
    ],
  },
  {
    label: "Storage & Hardware",
    items: [
      { to: "/storage", label: "Storage" },
      { to: "/cleanup", label: "Cleanup" },
      { to: "/hardware", label: "Hardware" },
      { to: "/networking", label: "Networking" },
    ],
  },
  {
    label: "Protect",
    items: [
      { to: "/security", label: "Security" },
      { to: "/backups", label: "Backups" },
    ],
  },
  {
    label: "Advanced",
    items: [
      { to: "/containers", label: "Containers" },
      { to: "/vms", label: "Virtual Machines" },
      { to: "/logs", label: "Logs" },
    ],
  },
];

export function AppShell() {
  return (
    <div className="app-shell">
      <aside className="app-shell__sidebar">
        <div className="app-shell__brand">
          <span className="app-shell__brand-mark" aria-hidden />
          <span>Control Center</span>
        </div>
        <nav>
          {NAV_GROUPS.map((group) => (
            <div className="app-shell__nav-group" key={group.label}>
              <div className="app-shell__nav-label">{group.label}</div>
              {group.items.map((item) => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  end={item.to === "/"}
                  className={({ isActive }) =>
                    "app-shell__nav-item" + (isActive ? " app-shell__nav-item--active" : "")
                  }
                >
                  {item.label}
                </NavLink>
              ))}
            </div>
          ))}
        </nav>
      </aside>
      <div className="app-shell__main">
        <header className="app-shell__topbar">
          <button className="app-shell__search" type="button" aria-label="Open universal search">
            Search packages, services, logs, settings…
            <kbd>⌘K</kbd>
          </button>
        </header>
        <main className="app-shell__content">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
