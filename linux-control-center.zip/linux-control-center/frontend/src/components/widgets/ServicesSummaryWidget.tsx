import { usePolledWidget } from "../../lib/usePolledWidget";
import type { ServicesSummary } from "../../types-systemd";
import { WidgetCard } from "../WidgetCard";

export function ServicesSummaryWidget() {
  const { data, error } = usePolledWidget<ServicesSummary>("systemd", "summary", 10_000);

  return (
    <WidgetCard title="Services">
      {error && <p className="mono" style={{ color: "var(--color-ember)" }}>{error}</p>}
      {data && (
        <div>
          <div style={{ fontFamily: "var(--font-display)", fontSize: 32, fontWeight: 600 }}>
            {data.running}
            <span style={{ fontSize: 16, color: "var(--color-text-faint)" }}> / {data.total}</span>
          </div>
          <div className="mono" style={{ fontSize: 12, color: data.failed > 0 ? "var(--color-ember)" : "var(--color-text-faint)" }}>
            {data.failed > 0 ? `${data.failed} failed` : "all running units healthy"}
          </div>
        </div>
      )}
    </WidgetCard>
  );
}
