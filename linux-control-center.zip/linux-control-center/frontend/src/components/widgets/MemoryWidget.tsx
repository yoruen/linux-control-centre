import { usePolledWidget } from "../../lib/usePolledWidget";
import type { MemoryWidgetData } from "../../types";
import { WidgetCard } from "../WidgetCard";

function formatBytes(bytes: number): string {
  const gb = bytes / 1024 ** 3;
  return `${gb.toFixed(1)} GB`;
}

export function MemoryWidget() {
  const { data, error } = usePolledWidget<MemoryWidgetData>("sysinfo", "memory", 1500);
  const percent = data ? Math.round((data.used_bytes / data.total_bytes) * 100) : 0;

  return (
    <WidgetCard title="Memory">
      {error && <p className="mono" style={{ color: "var(--color-ember)" }}>{error}</p>}
      {data && (
        <div>
          <div style={{ fontFamily: "var(--font-display)", fontSize: 32, fontWeight: 600 }}>
            {percent}
            <span style={{ fontSize: 16, color: "var(--color-text-faint)" }}>%</span>
          </div>
          <div className="mono" style={{ fontSize: 12, color: "var(--color-text-faint)" }}>
            {formatBytes(data.used_bytes)} / {formatBytes(data.total_bytes)}
          </div>
          <div
            role="progressbar"
            aria-valuenow={percent}
            aria-valuemin={0}
            aria-valuemax={100}
            style={{
              marginTop: 8,
              height: 6,
              borderRadius: 3,
              background: "var(--color-border)",
              overflow: "hidden",
            }}
          >
            <div
              style={{
                width: `${percent}%`,
                height: "100%",
                background: "var(--color-accent)",
              }}
            />
          </div>
        </div>
      )}
    </WidgetCard>
  );
}
