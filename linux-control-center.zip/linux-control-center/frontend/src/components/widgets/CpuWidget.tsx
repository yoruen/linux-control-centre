import { usePolledWidget } from "../../lib/usePolledWidget";
import type { CpuWidgetData } from "../../types";
import { WidgetCard } from "../WidgetCard";
import { PulseStrip } from "../PulseStrip";

export function CpuWidget() {
  const { data, error } = usePolledWidget<CpuWidgetData>("sysinfo", "cpu", 1500);

  return (
    <WidgetCard title="CPU" pulse={data && <PulseStrip values={data.per_core_percent} />}>
      {error && <p className="mono" style={{ color: "var(--color-ember)" }}>{error}</p>}
      {data && (
        <div>
          <div style={{ fontFamily: "var(--font-display)", fontSize: 32, fontWeight: 600 }}>
            {Math.round(data.overall_percent)}
            <span style={{ fontSize: 16, color: "var(--color-text-faint)" }}>%</span>
          </div>
          <div className="mono" style={{ fontSize: 12, color: "var(--color-text-faint)" }}>
            {data.per_core_percent.length} cores
          </div>
        </div>
      )}
    </WidgetCard>
  );
}
