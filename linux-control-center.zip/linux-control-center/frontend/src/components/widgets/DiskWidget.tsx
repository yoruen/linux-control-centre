import { WidgetCard } from "../WidgetCard";

// Full per-mount breakdown, SMART health, and largest-directories view ship
// with the Storage Manager module (see project roadmap). This card is the
// dashboard-level summary slot the storage plugin will populate once that
// module is built.
export function DiskWidget() {
  return (
    <WidgetCard title="Storage" span={2}>
      <p style={{ color: "var(--color-text-faint)", fontSize: 13 }}>
        Full disk breakdown arrives with the Storage Manager module.
      </p>
    </WidgetCard>
  );
}
