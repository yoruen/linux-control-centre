import "./ConfirmDialog.css";
import type { CommandDescriptor } from "../types-systemd";

export function ConfirmDialog({
  command,
  targetLabel,
  onConfirm,
  onCancel,
}: {
  command: CommandDescriptor;
  targetLabel: string;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  return (
    <div className="confirm-dialog__backdrop" role="presentation" onClick={onCancel}>
      <div
        className="confirm-dialog"
        role="alertdialog"
        aria-modal="true"
        aria-labelledby="confirm-dialog-title"
        onClick={(e) => e.stopPropagation()}
      >
        <h3 id="confirm-dialog-title">
          {command.id} — {targetLabel}
        </h3>
        <p className="confirm-dialog__description">{command.human_description}</p>
        <div className="confirm-dialog__command mono">
          {command.requires_privilege ? "pkexec " : ""}
          {command.program} {command.args_template.join(" ")} {targetLabel}
        </div>
        {command.requires_privilege && (
          <p className="confirm-dialog__note">
            This requires administrator authentication.
          </p>
        )}
        {command.destructive && (
          <p className="confirm-dialog__note confirm-dialog__note--warn">
            This action is hard to undo.
          </p>
        )}
        <div className="confirm-dialog__actions">
          <button className="confirm-dialog__cancel" onClick={onCancel}>
            Cancel
          </button>
          <button
            className={command.destructive ? "confirm-dialog__confirm--danger" : "confirm-dialog__confirm"}
            onClick={onConfirm}
          >
            Run
          </button>
        </div>
      </div>
    </div>
  );
}
