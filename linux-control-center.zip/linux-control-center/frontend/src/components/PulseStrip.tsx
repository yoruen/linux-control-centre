import "./PulseStrip.css";

/**
 * The one signature element repeated across every live-data widget: a thin
 * row of bars along the widget's top edge, height-mapped to real values
 * (per-core load, per-interface throughput, per-disk activity). It reads
 * as "this machine's pulse" rather than as a chart-junk sparkline, and its
 * consistent placement is what visually ties every module in the app
 * together as one instrument panel.
 */
export function PulseStrip({ values, max = 100 }: { values: number[]; max?: number }) {
  return (
    <div className="pulse-strip" role="img" aria-label={`Live values: ${values.map((v) => Math.round(v)).join(", ")}`}>
      {values.map((v, i) => (
        <span
          key={i}
          className="pulse-strip__bar"
          style={{ height: `${Math.max(6, Math.min(100, (v / max) * 100))}%` }}
        />
      ))}
    </div>
  );
}
