import { HashRouter, Routes, Route } from "react-router-dom";
import { AppShell } from "./components/AppShell";
import { Dashboard } from "./routes/Dashboard";
import { ServiceManager } from "./routes/ServiceManager";
import { ComingSoon } from "./routes/ComingSoon";

// HashRouter, not BrowserRouter: Tauri serves the frontend from a local
// asset protocol, not a real HTTP server with server-side routing support.
export function App() {
  return (
    <HashRouter>
      <Routes>
        <Route element={<AppShell />}>
          <Route path="/" element={<Dashboard />} />
          <Route path="/software" element={<ComingSoon moduleName="Software Center" />} />
          <Route path="/updates" element={<ComingSoon moduleName="Update Center" />} />
          <Route path="/repositories" element={<ComingSoon moduleName="Repository Manager" />} />
          <Route path="/services" element={<ServiceManager />} />
          <Route path="/processes" element={<ComingSoon moduleName="Process Manager" />} />
          <Route path="/startup" element={<ComingSoon moduleName="Startup Manager" />} />
          <Route path="/storage" element={<ComingSoon moduleName="Storage Manager" />} />
          <Route path="/cleanup" element={<ComingSoon moduleName="Cleanup Center" />} />
          <Route path="/hardware" element={<ComingSoon moduleName="Hardware Center" />} />
          <Route path="/networking" element={<ComingSoon moduleName="Networking" />} />
          <Route path="/security" element={<ComingSoon moduleName="Security Center" />} />
          <Route path="/backups" element={<ComingSoon moduleName="Backup Center" />} />
          <Route path="/containers" element={<ComingSoon moduleName="Containers" />} />
          <Route path="/vms" element={<ComingSoon moduleName="Virtual Machines" />} />
          <Route path="/logs" element={<ComingSoon moduleName="Logs" />} />
        </Route>
      </Routes>
    </HashRouter>
  );
}
