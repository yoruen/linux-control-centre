// Linux Control Center — Tauri backend entrypoint.
//
// This binary's job is narrow on purpose: build the distro-agnostic core
// (`lcc-core`), register the built-in plugins, and expose a small set of
// generic IPC commands to the React frontend. It must never contain
// distro-specific or tool-specific logic itself — that belongs in plugins.

mod state;

use lcc_core::{registry::PluginRegistry, DistroInfo};
use state::AppState;
use std::sync::Arc;
use tokio::sync::Mutex;

fn main() {
    tracing_subscriber::fmt::init();
    refuse_to_run_as_root();

    tauri::Builder::default()
        .setup(|app| {
            let handle = app.handle().clone();
            tauri::async_runtime::spawn(async move {
                if let Err(err) = bootstrap(handle).await {
                    tracing::error!("failed to bootstrap application: {err:#}");
                }
            });
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            state::list_plugins,
            state::universal_search,
            state::get_widget_data,
            state::list_plugin_commands,
            state::run_plugin_command,
        ])
        .run(tauri::generate_context!())
        .expect("error while running Linux Control Center");
}

/// Never run as root — the app escalates per-command via Polkit instead of
/// running the whole process (and therefore the whole Tauri/webview stack)
/// with root privileges. See the security section of the architecture doc.
fn refuse_to_run_as_root() {
    // SAFETY: geteuid() has no preconditions and cannot fail.
    let euid = unsafe { libc_geteuid() };
    if euid == 0 {
        eprintln!(
            "Linux Control Center must not be run as root. \
             Individual privileged actions are escalated per-command via Polkit."
        );
        std::process::exit(1);
    }
}

// Minimal FFI shim so this file doesn't need to pull in the whole `libc`
// crate just for one syscall.
extern "C" {
    #[link_name = "geteuid"]
    fn libc_geteuid() -> u32;
}

async fn bootstrap(app_handle: tauri::AppHandle) -> anyhow::Result<()> {
    let distro = DistroInfo::detect()?;
    tracing::info!(distro = %distro.pretty_name, "detected distribution");

    let data_dir = directories::ProjectDirs::from("org", "LinuxControlCenter", "lcc")
        .map(|d| d.data_dir().to_path_buf())
        .ok_or_else(|| anyhow::anyhow!("could not resolve platform data directory"))?;
    let db = lcc_core::db::connect(&data_dir).await?;

    let mut registry = PluginRegistry::new(distro, db);

    // Built-in plugins. Third-party/distro-specific plugins (apt, pacman,
    // dnf, systemd, docker, ...) register the same way from their own
    // crates — this list grows one module at a time per the milestone plan.
    registry
        .register(Box::new(lcc_plugin_sysinfo::SysInfoPlugin::default()))
        .await?;
    registry
        .register(Box::new(lcc_plugin_systemd::SystemdPlugin::default()))
        .await?;

    app_handle.manage(AppState { registry: Arc::new(Mutex::new(registry)) });
    Ok(())
}
