use lcc_core::PluginRegistry;
use lcc_plugin_api::{CommandDescriptor, CommandOutput, PluginId, PluginMetadata, SearchResultItem};
use serde_json::Value;
use std::sync::Arc;
use tokio::sync::Mutex;

pub struct AppState {
    pub registry: Arc<Mutex<PluginRegistry>>,
}

/// Every module (Software Center, Service Manager, ...) is reachable from
/// the frontend through these three generic verbs plus whatever
/// module-specific routes plugins register — the frontend never needs a
/// bespoke Tauri command per plugin.

#[tauri::command]
pub async fn list_plugins(state: tauri::State<'_, AppState>) -> Result<Vec<PluginMetadata>, String> {
    let registry = state.registry.lock().await;
    Ok(registry.list_metadata())
}

#[tauri::command]
pub async fn universal_search(
    state: tauri::State<'_, AppState>,
    query: String,
) -> Result<Vec<SearchResultItem>, String> {
    let registry = state.registry.lock().await;
    Ok(registry.search_all(&query).await)
}

#[tauri::command]
pub async fn get_widget_data(
    state: tauri::State<'_, AppState>,
    plugin_id: String,
    widget_id: String,
) -> Result<Value, String> {
    let registry = state.registry.lock().await;
    let plugin = registry
        .get(&PluginId(plugin_id.clone()))
        .ok_or_else(|| format!("plugin '{plugin_id}' not loaded"))?;
    let guard = plugin.lock().await;
    guard
        .widget_data(&widget_id)
        .await
        .map_err(|e| e.to_string())
}

/// Returns every command a plugin declared, so the frontend can render an
/// accurate confirmation dialog (and the AI assistant can explain the
/// command) *before* the user ever triggers `run_plugin_command`.
#[tauri::command]
pub async fn list_plugin_commands(
    state: tauri::State<'_, AppState>,
    plugin_id: String,
) -> Result<Vec<CommandDescriptor>, String> {
    let registry = state.registry.lock().await;
    Ok(registry.list_commands(&PluginId(plugin_id)).await)
}

/// Executes a previously-declared command. The frontend is responsible for
/// showing a confirmation dialog first when `descriptor.destructive` is
/// true (or always, for privileged commands) — this function performs no
/// confirmation itself, it only enforces that the command was declared and
/// routes privileged commands through Polkit.
#[tauri::command]
pub async fn run_plugin_command(
    state: tauri::State<'_, AppState>,
    plugin_id: String,
    command_id: String,
    substitutions: Vec<String>,
) -> Result<CommandOutput, String> {
    let registry = state.registry.lock().await;
    registry
        .run_command(&PluginId(plugin_id), &command_id, substitutions)
        .await
        .map_err(|e| e.to_string())
}
