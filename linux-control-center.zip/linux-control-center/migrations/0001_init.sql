CREATE TABLE IF NOT EXISTS plugin_config (
    plugin_id TEXT NOT NULL,
    key       TEXT NOT NULL,
    value     TEXT NOT NULL,
    PRIMARY KEY (plugin_id, key)
);

CREATE TABLE IF NOT EXISTS action_history (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    plugin_id     TEXT NOT NULL,
    command_id    TEXT NOT NULL,
    requested_at  TEXT NOT NULL,
    completed_at  TEXT,
    exit_code     INTEGER,
    privileged    INTEGER NOT NULL,
    description   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS search_index (
    plugin_id  TEXT NOT NULL,
    ref_id     TEXT NOT NULL,
    category   TEXT NOT NULL,
    title      TEXT NOT NULL,
    subtitle   TEXT,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (plugin_id, ref_id)
);

CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS telemetry_opt_in (
    enabled INTEGER NOT NULL DEFAULT 0
);
